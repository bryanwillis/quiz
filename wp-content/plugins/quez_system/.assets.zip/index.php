<?php
/*
Plugin Name: Quez System
Plugin URI: http://www.defox.pk
Author: M.Shoaib Mughal
Author URI: http://www.defox.pk
Version: 1.0
Description: It is golden quez system.
*/

include 'core/core.php';
//function quez_admin_assets(){
//    wp_enqueue_style( 'style',  plugins_url( '/assets/css/style.css', __FILE__ ), false );
//}
//add_action('admin_enqueue_scripts', 'quez_admin_assets');